# CS3110-final-project


# Installation
- Step 0: Install the graphics and camlimages packages; see below for more details

- Step 1: Download the zip file and upzip it;

- Step 2: In the directory, run [make build] and then [make play] command;

- Step 3: Press any key to start the game.

- Step 4: Close the window to stop the game. 

# How to play the game
Once the window is open, press any key to start the game.

### To move player 1, press the following keys on keyboard:

 - "w" to move the player one tile upwards;
 - "s" to move the player one tile downwards; 
 - "a" to move the player one tile leftwards; 
 - "d" to move the player one tile rightwards; 

### To move player 2, press the following keys on keyboard:
  
 - "i" to move the player one tile upwards;
 - "k" to move the player one tile downwards; 
 - "j" to move the player one tile leftwards; 
 - "l" to move the player one tile rightwards; 


Note that a move that causes the player to end up on an obstacle/boundary will not take place.
Also, if the input command is anything other than the above characters, a warning will be printed and ask you to retype an input. 
The objective of the game is to push all blocks (yellow) into holes (black X). 
Once all the holes have been filled, both players must step on the exit to teleport to the next level (gate image).
You can push multiple blocks in a row, and other players, but all players will be able to step on the exit simultaneously to go to the next level.
There are breakable objects which are depicted as gray blocks. You can try to "walk" on them twice (press the key that would otherwise cause you to collide with the object) to break them and turn that tile into a walkable tile. You do not need to break all these objects to finish the level.
The last room is a "win" room which has no exit and a win message displayed.

Click on the "RESET" button to reset the game, restarting from first level.
Click on the "QUIT" button to quit the game.

# Getting the GUI to Work
## For Mac:
NOTE: 
You will need to install X11/XQuartz for Graphics support. 
If you installed ocaml with homebrew, it can be done by running

`$ brew install Caskroom/cask/xquartz`

`$ brew reinstall ocaml --with-x11`

- Step 1: create a new switch for the game by running the command 

    `$ opam switch create <name> 4.07.1`

- Step 2: run

    `$ opam install graphics`

    `$ opam update`

    `$ opam upgrade`

    `$ eval $(opam env)`

    NOTE: If the installation of graphics module is successful, then the
    following commands should have you open a XQuartz window:

    `$ ocaml`

    `$ #load "graphics.cma";;`

    `$ Graphics.open_graph "";;`

- Step 3: run 

    `$ opam install -y utop ounit qcheck ocaml-lsp-server ocamlformat yojson ansiterminal csv bisect_ppx-ocamlbuild menhir user-setup`
    
    `$ opam user-setup install`

- Step 4: run 

    `$ opam install camlimages`

NOTE: All of the terminal commands from step 1 to step 4 are included in the script macinstall.sh. Mac users can run this script in their terminal to install all packages needed. 



## For Windows:
- Step 1: create a new switch for the game by running the command 

    `$ opam switch create <name> 4.07.1`

- Step 2: run

    `$ sudo apt install pkg-config`

    `$ opam install graphics`

    `$ opam update`

    `$ opam upgrade`

    `$ eval $(opam env)`  

- Step 3: install Xming available here: [Xming](https://sourceforge.net/projects/xming/)

- Step 3b: check to make sure running the following code opens up a blank window (make sure Xming has a server running):

    `$ ocaml`
    
    `$ #load “graphics.cma”;;`

    `$ Graphics.open_graph “localhost:0.0”;;`

- Step 4: run

    `$ sudo apt-get install libpng-dev`
    
    `$ opam install camlimages`
    
- Step 5: run 

    `$ opam install -y utop ounit qcheck ocaml-lsp-server ocamlformat yojson ansiterminal csv bisect_ppx-ocamlbuild menhir user-setup`
    
    `$ opam user-setup install`

Note: you will need to change `Graphics.open_graph “ 600x600”` to `Graphics.open_graph “localhost:0.0 600x600”` in the main.ml file inside the main () function around line 190.


# Modules implemented
## Main:
Calls functions in other modules to run the game.

## Types: 
Contains all types used in other modules.

## Map:
Contains the maps used for the game.

## State:
Contains functions that store game's current states and update states.

## Command:
Contains functions that parse command line input to a command type.

## Gui:
Contains functions used to print the game to the screen.

