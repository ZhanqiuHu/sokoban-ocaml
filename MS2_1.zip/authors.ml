let hx_hours_worked = 20

let slt_hours_worked = 20

let zh_hours_worked = 20

let kz_hours_worked = 20
