open Types

type 'a mutable_pos_list = { mutable list : 'a list }

let rec init_breakables pos_list hp_val =
  match pos_list with
  | h :: t -> { position = h; hp = hp_val } :: init_breakables t hp_val
  | _ -> []

let rec init_blocks pos_list =
  match pos_list with
  | h :: t -> { position = h; in_hole = false } :: init_blocks t
  | _ -> []

let rec init_holes pos_list =
  match pos_list with
  | h :: t -> { position = h } :: init_holes t
  | _ -> []

let update_positions tile_map =
  let y_end = Array.length tile_map - 1 in
  let x_end = Array.length tile_map.(0) - 1 in
  for x = 0 to x_end do
    for y = 0 to y_end do
      tile_map.(y).(x) <-
        { position = (x, y_end - y); ttype = tile_map.(y).(x).ttype }
    done
  done;
  tile_map

let map_init map_w map_h init_val =
  update_positions (Array.make_matrix map_h map_w init_val)

let random_bool true_prob =
  let random_val = Random.float 100. in
  if random_val <= 100. *. true_prob then true else false

let init_boundary (init_map : tile array array) bound_val =
  let y_end = Array.length init_map - 1 in
  let x_end = Array.length init_map.(0) - 1 in
  for x = 0 to x_end do
    for y = 0 to y_end do
      if x = 0 || x = x_end then
        init_map.(y).(x) <-
          {
            position = init_map.(y).(x).position;
            ttype = bound_val.ttype;
          }
      else if y = 0 || y = y_end then
        init_map.(y).(x) <-
          {
            position = init_map.(y).(x).position;
            ttype = bound_val.ttype;
          }
      else ()
    done
  done;
  init_map

let set map x_pos y_pos new_val =
  let y_end = Array.length map - 1 in
  map.(y_end - y_pos).(x_pos) <- new_val;
  map

let set_with_same_pos (map : tile array array) x_pos y_pos new_val =
  let y_end = Array.length map - 1 in
  map.(y_end - y_pos).(x_pos) <-
    {
      position = map.(y_end - y_pos).(x_pos).position;
      ttype = new_val.ttype;
    };
  map

let get map x_pos y_pos =
  let y_end = Array.length map - 1 in
  map.(y_end - y_pos).(x_pos)

let copy_map map =
  let new_map = Array.copy map in
  let y_end = Array.length map - 1 in
  for y = 0 to y_end do
    map.(y) <- Array.copy map.(y)
  done;
  new_map

let define_path_map (map : tile array array) path_list path_val =
  let y_end = Array.length map - 1 in
  let map_copy = copy_map map in
  let rec set_path path_pos_list =
    match path_pos_list with
    | (hx, hy) :: t ->
        let _ =
          map_copy.(y_end - hy).(hx) <-
            {
              position = map_copy.(hy).(hx).position;
              ttype = path_val.ttype;
            }
        in
        set_path t
    | _ -> ()
  in
  let _ = set_path path_list in
  map_copy

let iterate map func =
  let y_end = Array.length map - 1 in
  let x_end = Array.length map.(0) - 1 in
  for x = 0 to x_end do
    for y = 0 to y_end do
      func x y
    done
  done

let choose_obstacles
    map
    path_list
    path_val
    tile_val
    obstacle_val
    true_prob =
  let path_map = define_path_map map path_list path_val in
  let y_end = Array.length map - 1 in
  let x_end = Array.length map.(0) - 1 in
  for x = 0 to x_end do
    for y = 0 to y_end do
      if
        map.(y).(x).ttype = tile_val.ttype
        && path_map.(y).(x).ttype <> path_val.ttype
      then
        if random_bool true_prob then
          map.(y).(x) <-
            {
              position = map.(y).(x).position;
              ttype = obstacle_val.ttype;
            }
        else ()
      else ()
    done
  done

let generate_breakables map path_list path_val tile_val true_prob =
  let pos_list = { list = [] } in
  let path_map = define_path_map map path_list path_val in
  let y_end = Array.length map - 1 in
  let x_end = Array.length map.(0) - 1 in
  for x = 0 to x_end do
    for y = 0 to y_end do
      if
        map.(y).(x).ttype = tile_val.ttype
        && path_map.(y).(x).ttype <> path_val.ttype
      then
        if random_bool true_prob then
          pos_list.list <- (x, y_end - y) :: pos_list.list
        else ()
      else ()
    done
  done;
  pos_list.list

let map_to_list map =
  let array_list = Array.to_list map in
  List.map (fun arr -> Array.to_list arr) array_list

let new_map_with_obstacles
    map_w
    map_h
    tile_val
    bound_val
    path_val
    obstacle_val
    path_pos_list
    obstacle_prob =
  let map = map_init map_w map_h tile_val in
  let _ = init_boundary map bound_val in
  let _ =
    choose_obstacles map path_pos_list path_val tile_val obstacle_val
      obstacle_prob
  in
  map

let generate_path_pos
    exit_pos_list
    init_pos_list
    hole_pos_list
    block_pos_list =
  let new_list =
    exit_pos_list @ init_pos_list @ hole_pos_list @ block_pos_list
  in
  let path_list = { list = new_list } in
  let rec helper pos_lst path_lst =
    match pos_lst with
    | (x1, y1) :: (x2, y2) :: t ->
        let x_start = if x1 <= x2 then x1 else x2 in
        let x_end = if x1 <= x2 then x1 else x2 in
        let y_start = if y1 <= y2 then y1 else y2 in
        let y_end = if y1 <= y2 then y1 else y2 in
        for x = x_start to x_end do
          path_lst.list <- (x, y_start) :: path_lst.list
        done;
        for y = y_start to y_end do
          path_lst.list <- (x_end, y) :: path_lst.list
        done;
        helper ((x2, y2) :: t) path_lst
    | _ -> path_lst.list
  in
  helper new_list path_list

(* let map_try = let map_w = 10 in let map_h = 5 in let tile_val =
   "tile" in let bound_val = "bound" in let path_val = "path" in let
   obstacle_val = "obstacle" in let path_pos_list = [] in let
   obstacle_prob = 0.5 in new_map_with_obstacles map_w map_h tile_val
   bound_val path_val obstacle_val path_pos_list obstacle_prob *)
